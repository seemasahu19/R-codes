# Read the dataset
# Load the libraries

# install.packages('tidyr')
# install.packages('DT')
# install.packages('knitr')
# install.packages('gridExtra')
# install.packages('corrplot')
# install.packages('qgraph')


library(recommenderlab)
library(dplyr)
library(tidyr)
library(ggplot2)
library(corrplot)
library(Matrix)


ratings <- read.csv('ratings_small.csv')

# Clean the dataset
# Remove the duplicate ratings

# ratings[, N := .N, .(user_id, book_id)]
ratings <- ratings %>% group_by(user_id, book_id) %>% mutate(n = n())
# Concatenate & Print
cat('Number of duplicate ratings: ', nrow(ratings[ratings$n > 1,]))
ratings <- ratings[ratings$n == 1, ]
ratings$n <- NULL

# Remove users who rated fewer than 3 books

# ratings[, N := .N, .(user_id)]
ratings <- ratings %>% group_by(user_id) %>% mutate(n = n())
cat('Number of users who rated fewer than 3 books: ', nrow(ratings[ratings$n < 3, ]))
ratings <- ratings[ratings$n >= 3, ]
ratings$n <- NULL

## What is the distribution of ratings?

ratings %>% 
  ggplot(aes(x = rating, fill = factor(rating))) +
  geom_bar(color = "grey20") 

# Number of ratings per user

ratings %>% 
  group_by(user_id) %>% 
  summarize(number_of_ratings_per_user = n()) %>% 
  ggplot(aes(number_of_ratings_per_user)) + 
  geom_bar(fill = "cadetblue3", color = "grey20") + coord_cartesian(c(3, 50))

# Distribution of mean user ratings per user

ratings %>% 
  group_by(user_id) %>% 
  summarize(mean_user_rating = mean(rating)) %>% 
  ggplot(aes(mean_user_rating)) +
  geom_histogram(fill = "cadetblue3", color = "grey20")


# Distribution of mean book ratings per book

ratings %>% 
  group_by(book_id) %>% 
  summarize(mean_book_rating = mean(rating)) %>% 
  ggplot(aes(mean_book_rating)) + geom_histogram(fill = "orange", color = "grey20") + coord_cartesian(c(1,5))

# Recommender System

# Restructure the Data
dimension_names <- list(user_id = sort(unique(ratings$user_id)), book_id = sort(unique(ratings$book_id)))
ratingmat <- spread(select(ratings, book_id, user_id, rating), book_id, rating)
ratingmat$user_id <- NULL


ratingmat <- as.matrix(ratingmat)
dimnames(ratingmat) <- dimension_names
ratingmat[1:5, 1:5]

dim(ratingmat)


# Using recommenderlab
# Replacing NA with 0

ratingmat0 <- ratingmat
ratingmat0[is.na(ratingmat0)] <- 0
ratingmat0[1:5, 1:5]
sparse_ratings <- as(ratingmat0, "sparseMatrix")
rm(ratingmat0)


real_ratings <- new("realRatingMatrix", data = sparse_ratings)
real_ratings

# Creating the model 

model <- Recommender(real_ratings, method = "UBCF", param = list(method = "pearson", nn = 4))

# Making predictions
# Define current user
# prediction <- predict(model, real_ratings[current_user, ], type = "ratings")

# Evaluating the predictions

# The given parameter determines how many ratings are given to create the 
# predictions and in turn on how many predictions per user remain for the 
# evaluation of the prediction. In this case -1 means that the 
# predictions are calculated from all but 1 ratings, 
# and performance is evaluated for 1 for each user.

scheme <- evaluationScheme(real_ratings[1:50,], method = "cross-validation", k = 10, given = -1, goodRating = 5)

# In a second step, we can list all the algorithms we want to compare. 
# As we have a tuneable parameter nn, which is the number of most similar users
# which are used to calculate the predictions. Lets vary this parameter from 
# 5 to 50 and plot the RMSE. Furthermore, as a baseline one can also add 
# an algorithm ("RANDOM") that randomly predicts a rating for each user

algorithms <- list("random" = list(name = "RANDOM", param = NULL),
                   "UBCF_05" = list(name = "UBCF", param = list(nn = 5)),
                   "UBCF_10" = list(name = "UBCF", param = list(nn = 10)),
                   "UBCF_30" = list(name = "UBCF", param = list(nn = 30)),                   
                   "UBCF_50" = list(name = "UBCF", param = list(nn = 50)))

# evaluate the alogrithms with the given scheme

results <- evaluate(scheme, method = algorithms, type = "ratings")


# restructure results output

tmp <- lapply(results, function(x) slot(x, "results"))
res <- tmp %>% 
  lapply(function(x) unlist(lapply(x, function(x) unlist(x@cm[ ,"RMSE"])))) %>% 
  as.data.frame() %>% 
  gather(key = "Algorithm", value = "RMSE")

res %>% 
  ggplot(aes(Algorithm, RMSE, fill = Algorithm)) +
  geom_bar(stat = "summary") + geom_errorbar(stat = "summary", width = 0.3, size = 0.8) +
  coord_cartesian(ylim = c(0.6, 1.3)) + guides(fill = FALSE)

# Different algorithms

# The following algorithms are available
recommenderRegistry$get_entry_names()

# You can get more information about these algorithms
recommenderRegistry$get_entries(dataType = "realRatingMatrix")



scheme <- evaluationScheme(real_ratings[1:50,], method = "cross-validation", k = 10, given = -1, goodRating = 5)

algorithms <- list("random" = list(name = "RANDOM", param = NULL),
                   "popular" = list(name = "POPULAR"),
                   "UBCF" = list(name = "UBCF"),
                   "SVD" = list(name = "SVD")
)

results <- evaluate(scheme, algorithms, type = "ratings", progress = FALSE)



# restructure results output
tmp <- lapply(results, function(x) slot(x, "results"))
res <- tmp %>% 
  lapply(function(x) unlist(lapply(x, function(x) unlist(x@cm[ ,"RMSE"])))) %>% 
  as.data.frame() %>% 
  gather(key = "Algorithm", value = "RMSE")

res %>% 
  mutate(Algorithm=factor(Algorithm, levels = c("random", "popular", "UBCF", "SVD"))) %>%
  ggplot(aes(Algorithm, RMSE, fill = Algorithm)) + geom_bar(stat = "summary") + 
  geom_errorbar(stat = "summary", width = 0.3, size = 0.8) + coord_cartesian(ylim = c(0.6, 1.3)) + 
  guides(fill = FALSE)

